export type DatePickerMessages = {
  nextMonth: string;
  prevMonth: string;
  year: string;
};
