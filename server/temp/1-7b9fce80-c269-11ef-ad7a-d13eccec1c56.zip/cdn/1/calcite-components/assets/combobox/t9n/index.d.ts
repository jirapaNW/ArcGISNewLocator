export type ComboboxMessages = {
  all: string;
  allSelected: string;
  clear: string;
  removeTag: string;
  selected: string;
};
